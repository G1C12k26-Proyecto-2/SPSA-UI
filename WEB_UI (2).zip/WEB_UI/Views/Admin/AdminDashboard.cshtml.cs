using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Views.Admin
{
    public class AdminDashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
